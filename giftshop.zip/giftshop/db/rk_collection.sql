-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 07, 2024 at 09:27 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rk_collection`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `orderid` int(11) NOT NULL,
  `name` varchar(800) NOT NULL,
  `email` varchar(70) NOT NULL,
  `contact` varchar(60) NOT NULL,
  `address` varchar(5000) NOT NULL,
  `state` varchar(100) NOT NULL,
  `city` varchar(800) NOT NULL,
  `pincode` int(20) NOT NULL,
  `productname` varchar(70) NOT NULL,
  `productquantity` int(20) NOT NULL,
  `productprice` varchar(100) NOT NULL,
  `productimage` varchar(1000) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`orderid`, `name`, `email`, `contact`, `address`, `state`, `city`, `pincode`, `productname`, `productquantity`, `productprice`, `productimage`, `date`) VALUES
(0, 'Karan  Yadav', 'portraitor@gmail.com', '7505826739', 'Larampur Katara Sarai Aghat Aliganj Etah', 'Uttar Pradesh', 'Aliganj', 207250, '', 0, '', '', '2024-12-07'),
(0, 'Karan  Yadav', 'portraitor@gmail.com', '7505826739', 'Larampur Katara Sarai Aghat Aliganj Etah', 'Uttar Pradesh', 'Aliganj', 207250, 'Sweet Serenity Birthday Surpri', 1, '220', 'upload/sweet-serenity-birthday-surprise_1.webp', '2024-12-07');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `Category_name` varchar(50) NOT NULL,
  `Category_id` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`Category_name`, `Category_id`) VALUES
('birthday', 1),
('anniversary', 2),
('wedding', 3),
('toys', 5),
('decoration', 7),
('on trend', 8),
('festivals', 9),
('occasions', 11);

-- --------------------------------------------------------

--
-- Table structure for table `order_status`
--

CREATE TABLE `order_status` (
  `orderid` int(11) NOT NULL,
  `order_status` varchar(40) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `otp`
--

CREATE TABLE `otp` (
  `Email` varchar(50) NOT NULL,
  `otp` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `otp`
--

INSERT INTO `otp` (`Email`, `otp`) VALUES
('arjunsingh2827832@gmail.com', '3500'),
('arjunsingh2827832@gmail.com', '3457');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(100) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Category` varchar(40) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Description` varchar(10000) NOT NULL,
  `Price` int(11) NOT NULL,
  `Image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `Name`, `Category`, `Quantity`, `Description`, `Price`, `Image`) VALUES
(2, 'Personalized Coffee Lover Hamp', 'birthday', 4, 'Let the coffee lover in your life indulge in this Personalized Coffee Lover Hamper. This thoughtfully curated hamper consists of a black ceramic mug adorned with the words Coffee Lover. Accompanied by delicious instant coffee and dark chocolate waffle cookies that are perfect to enjoy with coffee. The hamper is completed with a wooden spoon, a black mini portable frother, and a coaster adorned with the words Coffee Over Everything, making it a perfect coffee lovers hamper. Personalize the mug wi', 200, 'upload/p-personalized-coffee-lover-hamper-334899-m.webp'),
(3, 'Full Of Qualities Personalised', 'birthday', 10, 'Product Details:  One Personalised Mug Material-Ceramic Dimensions-4 x 3 Inches Colour-Black Capacity-Can hold liquid upto 325 ml Microwave and dishwasher safe Net Quantity: 1 Unit Country Of Origin: India For personalisation, please provide us with one name', 240, 'upload/full-of-qualities-personalised-mug-hand-delivery_1.webp'),
(4, 'Blue Bloom Chocolate Delight', 'birthday', 3, 'Introducing our delightful chocolate bliss. Each piece is adorned with delicate blue gypsophila and elegantly wrapped in a white sheet. Perfect for Womens Day or any occasion, its a sweet gesture to show appreciation and love. This gift brings joy and indulgence, adding sweetness to the recipients day and warming their heart with every bite.', 300, 'upload/blue-bloom-chocolate-delight_1.webp'),
(5, 'Sweet Serenity Birthday Surpri', 'birthday', 3, 'Unveil the epitome of sweet elegance with this captivating hamper. Nestled within are delightful treasures, including chocolate, complemented by the soft blush of peach roses and the regal allure of purple daisies. This gift weaves a tapestry of joy, infusing the recipients life with the warmth of affection and the simple yet profound pleasures of life.', 220, 'upload/sweet-serenity-birthday-surprise_1.webp'),
(6, 'Personalized Golden Chic Brace', 'birthday', 4, 'A stunning piece of elegance, this Golden Chic Bracelet by Salty combines timeless charm with modern flair. Featuring a delicate gold finish chain and a secure lobster claw clasp, it drapes beautifully on the wrist. ', 695, 'upload/p-personalized-golden-chic-bracelet-385578-m.webp'),
(7, 'Personalized Best Of Us Memori', 'anniversary', 4, 'Cherish your favourite moments with love and a beautiful keepsake. Crafted from high-quality materials, these enchanting wooden photo frames consist of three individual photo grids in acrylic with your chosen photos, giving them a glossy look and feel.', 1695, 'upload/p-personalized-best-of-us-memories-frame-272793-m.webp'),
(8, 'Radiant Memories Personalized ', 'anniversary', 7, 'Give your home an adorable addition with this LED fur cushion. Crafted with high-quality materials, this cushion is soft and durable, ensuring it becomes a one-of-a-kind gift that your loved ones will cherish for years. ', 625, 'upload/p-radiant-memories-personalized-led-fur-cushion-273295-m.webp'),
(9, 'You And Me Forever LED Lamp - ', 'anniversary', 5, 'Illuminate your love story with this impressive colour-changing LED lamp. ', 745, 'upload/img16.webp');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Email` varchar(40) NOT NULL,
  `Contact` varchar(20) NOT NULL,
  `Password` varchar(10) NOT NULL,
  `Image` varchar(60) NOT NULL,
  `Address` varchar(900) NOT NULL,
  `utype` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `Name`, `Email`, `Contact`, `Password`, `Image`, `Address`, `utype`) VALUES
(1, 'Arjun Singh', 'arjunsingh2827832@gmail.com', '7505679042', '12345', 'profile-photo/img12.jpg', '', 'admin'),
(3, 'Karan Yadav', 'portraitor@gmail.com', '7505826739', '123456', 'profile-photo/img7.jpg', 'Larampur Katara Sarai Aghat Aliganj Etah', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`Category_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `Category_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
