<?php
include("connect.php");
include("mail-api/mail.php");
session_start();
if(isset($_POST['sub']))
{
    $otp=rand(999,9999);
    $Email=$_POST['Email'];
    $sql="select email from users where Email='$Email'";
    $res=mysqli_query($con,$sql);
    if(mysqli_num_rows($res)>0)
    {
        $sql1="insert into otp(Email,otp)values('$Email','$otp')";
        $res1=mysqli_query($con,$sql1);
        if($res1)
        {
            $_SESSION['Email']=$Email;
            mails($Email,'OTP',$otp);
            header("location:otp.php");
        }
    }
    else
    {
        $msg="Invalid Email";
    }
}

?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include("cdn.php");?>
    <style>
        .table{
            border-radius:20px 20px;
        }
        .table input{
            width: 100%;
 margin-top:10px;
 border:1px solid black;
        }
    </style>
</head>
<body>
    <div class="container my-5">
        <div class="row d-flex justify-content-center">
            <div class="col-lg-5 ">
                <div class="table border p-5">
                <h3>Reset Password</h3>
                <form method="post" class="form p-3">
                    <div class="form-group">
                        <label for="">Email</label>
                        <input type="email" class="form-control" name="Email">
                    </div>
                    <div class="form-group ">
                        <input type="submit" value="Submit" name="sub" class="btn" style="width:100%; background-color:maroon; color:white;" >
                        <p><?php if(isset($msg)) echo $msg; ?></p>
                    </div>
                </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>