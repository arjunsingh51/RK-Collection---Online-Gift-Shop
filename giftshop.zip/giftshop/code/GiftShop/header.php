<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RK Collection</title>
    <?php include("cdn.php");?>
    <style>
        body{
       
       
    }
    .n{
        background-color:white;
        position:relative;
    }
   
    
    .n .nav-link{
            color:black;
            font-size: 20px;
        
            font-style: initial;
        transition: 0.5s;
        justify-content: center;
        align-items: center;
        margin-left:10px;
    }
    .n .nav-link:hover{
        background-color:maroon;
        transition: 0.5s;
        border-radius: 15px;
        box-shadow: 2px 2px 2px 0px;
    
        background: transparent;
        color:maroon;
    }


    </style>
</head>
<body>
 <div class="sticky-top">
    <nav class="navbar navbar-expand-lg navbar-light n">
        <div class="container-fluid">
            <a href="home.php" class="navbar-brand chmtlogo" >
                <img src="img3.jpg" alt="clogo" height="50px" >
            </a>
            <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#nav" aria-controls="nav" aria-expanded="false">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="navbar-collapse collapse" id="nav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a href="check-cart.php" class="nav-link">Cart <i class='bx bxs-cart-add' ></i></a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="login.php" class="nav-link">Login <i class='bx bxs-log-in' ></i></a>
                    </li>
                   
                </ul>
                   
            </div>
        </div>
    </nav>
    <?php include("category.php");?>
 </div>  
</body>
</html>