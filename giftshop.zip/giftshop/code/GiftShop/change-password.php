<?php
include("connect.php");
include("mail-api/mail.php");
session_start();
$Email=$_SESSION['Email'];
if(isset($_POST['sub']))
{
    $Password=$_POST['Password'];
    $sql="update users set Password='$Password' where Email='$Email'";
    $res=mysqli_query($con,$sql);
    if($res)
    {
        mails($email,'password change confirmation','Password Successully Changed');
        header("location:login.php");
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include("cdn.php");?>
    <style> .table{
            border-radius:20px 20px;
        }
        .table input{
            width: 100%;
 margin-top:10px;
 border:1px solid black;
        }</style>
</head>
<body>
    <div class="container my-5">
        <div class="row d-flex justify-content-center">
            <div class="col-lg-6 border  p-4 ">
                <div class="table border p-5">
                <form method="post" class="form">
                    <div class="form-group">
                        <label for="">Password</label>
                        <input type="password" name="Password" class="form-control">
                    </div>
                    <div class="form-group">
                        <input type="submit" value="Change Password" name="sub" class="btn" style="width:100%; background-color:maroon; color:white;">
                    </div>
                </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>