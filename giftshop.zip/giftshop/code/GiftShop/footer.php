<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RK Collection</title>
    <?php include("cdn.php");?>
<style>
    .g{
        background-color:black;
        color:white;
        padding:5px;
    }
    .main{
        background-color:maroon;
        color:white;
        padding:20px;
        display:flex;
        justify-content:space-between;
        
    }
    .mid{
        margin-left:400px;
        
    }
    
    .footer{
        justify-content:center;
        align-items:center;
        text-align:center;
        
    }
    p{
        color:white;
        
    }
</style>
</head>
<body>
<div class="main">
       <div> <h4><i class='bx bxs-contact'></i><b>Contact Us</b></h4>
        <p >
            <i class='bx bxs-envelope'>: arjunsingh2827832@gmail.com</i>
            <i class='bx bxs-phone' >: +91 7505679042</i>
        </p>
        </div>
        <div class="mid">
            <h4><b>FollowUs</b></h4>
            <p style="justify-content:center; align-items:center; text-align:center;"><a href="#" style="color:white;"><i class='bx bxl-instagram' ></i></a>
               <a href="#" style="color:white;"><i class='bx bxl-facebook-circle'></i>
            </a><a href="#" style="color:white;"><i class='bx bxl-linkedin'></i></a>
        </p>
        </div>
        <div style="margin-left:300px;">
        <h4 style="justify-content:end;"><b>About Us</b></h4>
        <p>RKCollection.com is a brand-new idea cultivated by one experienced professionals who quit a technology company to start something new and innovative in the space of e-commerce.</p>
      </div>
      </div>
    <div class="container-fluid g">
        <div class="footer">
    <p>&copy; <?=date('Y'); ?> RK Gift Shop. All Rights Reserved.</p>
    </div>
    </div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
