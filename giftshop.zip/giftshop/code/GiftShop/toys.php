<?php 
  include("connect.php");
  
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BIRTHDAY</title>
    <?php include("cdn.php");?>
    <style>
      .pro{
         margin-top:20px;
         padding:10px;
      }
    </style>
</head>
<body>
<?php include("header.php");?>
<div class="container-fluid pro">
      <h3 style="text-align:center; color:maroon;">TOYS</h3>
      <div class="row p">
         <?php
           $sql="select * from product where Category='toys' order by id desc";
           $res=mysqli_query($con,$sql);
           if(mysqli_num_rows($res)>0)
           {
            while($r=mysqli_fetch_assoc($res))
            {
               echo' 
                  <div class="col-lg-3 col-sm-12"> 
                     <div class="card my-3">
                     <a href="description.php?id='.$r['id'].'" style="text-decoration:none;color:black;">
                     <form action="cart.php" method="post">
                     <input type="hidden" name="Name" value="'.$r['Name'].'">
                     <input type="hidden" name="Image" value="'.$r['Image'].'"/>
                     <input type="hidden" name="Price" value="'.$r['Price'].'">
                     <input type="hidden" name="Quantity" value="1"/>
                           <div class="card-header">
                            <img src="'.$r['Image'].'" class="img d-block w-100"></div>
                           <div class="card-body">
                            <h4>'.$r['Name'].'</h4>
                            <h6>'.$r['Price'].'</h6>
                           </div>
                           <div class="card-footer">
                           <a href="login.php" class="btn btn-outline-danger">Buy</a>
                           <button type="submit" class="btn btn-danger ms-5""><i class="bx bxs-cart-add"></i>Add To Cart</button>
                           </div>
                        </form> 
                        </a>  
                     </div>
                     </div>
                     
               ';
            }
           }
         ?>
      </div>
   </div>
           <?php include("footer.php");?>
</body>
</html>