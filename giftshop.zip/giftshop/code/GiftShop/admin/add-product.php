
<?php
    include("../connect.php");
    session_start();
    if(!isset($_SESSION['Email']))
    {
       header("location:../login.php");
    }
    if(isset($_POST['sub']))
    {
        $Name=$_POST['Name'];
        $Category=$_POST['Category'];
        $Quantity=$_POST['Quantity'];
        $Description=$_POST['Description'];
        $Price=$_POST['Price'];
        $path="../upload/".$_FILES['Image']['name'];
        $path1="upload/".$_FILES['Image']['name'];
        $tem=$_FILES['Image']['tmp_name'];
        if(move_uploaded_file($tem,$path))
        {
            $sql="insert into product(Name,Category,Quantity,Description,Price,Image)values('$Name','$Category','$Quantity','$Description','$Price','$path1')";
            $res=mysqli_query($con,$sql);
            if($res)
            {
                echo "<script>alert('Product Added Successfully')</script>";
                header("location:view-product.php");
            }
          
        }

    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include("../cdn.php");?>
    <style>
        h3{
            text-align:center;
            justify-content:center;
            align-items:center;
        }
        body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
   
    background-color: #f7f7f7;
    background:url();
    background-repeat:no-repeat;
    background-size:cover;
         }
      .card{
        border-radius:20px 20px;
        box-shadow:  0 8px 8px rgba(8, 4, 3, 0.1);
        
        overflow: hidden;
    background-color: #ffff;
    
      }
      .card input {
    width: 100%;
    padding:10px;
    border: 1px solid black;
    border-radius: 5px;
}
.card select {
    width: 100%;
    padding:10px;
    border: 1px solid black;
    border-radius: 5px;
}
header {
    background-color: maroon; 
    color: #fff;
    padding: 20px;
    text-align: center;
}
h1 {
    margin: 0;
}
    </style>
</head>
<body>
    <?php include("nav.php");?>
    <header><h1>Add Product</h1></header>
    <div class="container my-5">

        <div class="row d-flex justify-content-center">
            <div class="col-lg-5 col-12">
                <div class="card border   ">
                    <form method="post" class="form" enctype="multipart/form-data">
                    <div class="form-group my-3">
                        <label for="">Product Name</label>
                        <input type="text" name="Name" placeholder="Enter Product Name" id="" class="form-control">
                    </div>
                    <div class="form-group my-3">
                        <label for="">Product Category</label><br>
                        <select name="Category" id="" class="form-control">
                        <option value="">Select</option>
                      
                       <?php
                        $sql1="select * from category";
                        $res1=mysqli_query($con,$sql1);
                        if(mysqli_num_rows($res1)>0)
                        {
                            while($r1=mysqli_fetch_assoc($res1))
                            {
                                echo "<option value='".$r1['Category_name']."'>".$r1['Category_name']."</option>";
                            }
                        }
                       ?>
                        </select>
                    </div>
                    <div class="form-group my-3">
                        <label for="">Product Quantity</label>
                        <input type="text" name="Quantity" placeholder="Enter Product Quantity" id="" class="form-control">
                    </div>
                    <div class="form-group my-3">
                        <label for="">Product Description</label>
                        <input type="text" name="Description" placeholder="Enter Product Description" id="" class="form-control">
                    </div>
                    <div class="form-group my-3">
                        <label for="">Price</label>
                        <input type="text" name="Price" placeholder="Enter Price" id="" class="form-control">
                    </div>
                    <div class="form-group my-3">
                        <label for="">Product Image</label>
                        <input type="file" name="Image"  id="" class="form-control">
                    </div>
                    <div class="form-group ">
                        <input type="submit" value="Add" name="sub" class="btn"  style="background-color:maroon;color:White; width:100%;">
                    </div>
                </form>
                </div>
              
            </div>
        </div>
    </div>
</body>
</html>