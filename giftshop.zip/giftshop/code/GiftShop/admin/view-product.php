<?php
   include("../connect.php");
   session_start();
 if(!isset($_SESSION['Email']))
 {
    header("location:../login.php");
 }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include("../cdn.php");?>
<style>
    body {
        font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f7f7f7;
}

header {
    background-color: maroon; 
    color: #fff;
    padding: 20px;
    text-align: center;
}
h1 {
    margin: 0;
}

.container-fluid {
    padding: 40px;
    display: flex;
    justify-content: center;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
    background-color: #fff;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
    overflow: hidden;
}

th, td {
    padding: 12px 15px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}


tr:nth-child(even) {
    background-color: #f2f2f2;
}

tr:hover {
    background-color: #f1f1f1;
}


</style>
</head>
<body>
<?php include("nav.php");?>
    <header><h1>OUR PRODUCTS</h1></header>
<div class="container-fluid ">
        <table  class="table my-5 ">
            <thead class="l"> 
                <tr>
                    <th style="background-color:maroon; color:#fff">Sr.no.</th>
                    <th style="background-color:maroon; color:#fff">Name</th>
                    <th style="background-color:maroon; color:#fff" >Category</th>
                    <th style="background-color:maroon; color:#fff">Quantity</th>
                    <th style="background-color:maroon; color:#fff">Description</th>
                    <th style="background-color:maroon; color:#fff">Price</th>
                    <th style="background-color:maroon; color:#fff">Image</th>
                    <th style="background-color:maroon; color:#fff">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                
                $sql="select * from product" ;
                $res=mysqli_query($con,$sql);
                $sql1="select count(*) from product";
                if(mysqli_num_rows($res)>0)
                {
                    $i=1;
                    while($r=mysqli_fetch_array($res))
                    {
                        echo "<tr>
                        <td>".$i."</td>
                 <td>".$r['Name']."</td>
                 <td>".$r['Category']."</td>
                 <td>".$r['Quantity']."</td>
                 <td>".$r['Description']."</td>
                 <td>".$r['Price']."</td>
                  <td><img src='../".$r['Image']."' height='70px' width='70px'/></td>
                  <td><a href=delete-product.php?id=".$r['id']." style='color:maroon; ' class='btn'><i class='bx bx-trash bx-large'></i></a></td>
                        </tr>";
                        $i++;
                    }
                }

                ?>
            </tbody>
        </table>
            
    
    </div>
</body>
</html>