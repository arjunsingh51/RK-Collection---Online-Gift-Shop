<?php 
  session_start();
  if(!isset($_SESSION['Email']))
  {
     header("location:../login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include("../cdn.php")?>
    <style>
        body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f7f7f7;
        }
        header {
    background-color: maroon; 
    color: #fff;
    padding: 20px;
    text-align: center;
}
h1 {
    margin: 0;
}
.container-fluid{
            
    padding: 40px;
    display: flex;
    justify-content: center;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
    background-color: #fff;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
    overflow: hidden;
}

th, td {
    padding: 12px 15px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

th {
    background-color:maroon; 
    color: #fff;
}

tr:nth-child(even) {
    background-color: #f2f2f2;
}

tr:hover {
    background-color: #f1f1f1;
}
    </style>
</head>
<body>
    <?php include("nav.php");?>
    <header><h1>Category</h1></header>
    <div class="container-fluid ">
      <table>
        <thead>
            <th>Sr.no</th>
            <th>Category Name</th>
            <th>Action</th>
        </thead>
        <tbody>
        <?php
            include("../connect.php");
            $sql="select * from category";
            $res=mysqli_query($con,$sql);
            $sql1="select count(*) from category";
            if(mysqli_num_rows($res)>0)
            {
                    $i=1;
                while($r=mysqli_fetch_assoc($res))
                {
                    echo"
                        <tr>
                            <td>".$i."</td>
                            <td>".$r['Category_name']."</td>
                            <td>
                                <a href='delete.php?id=".$r['Category_id']."' style='color:maroon;'><i class='bx bx-trash'></i></a>
                            </td>
                        </tr>
                    ";
                    $i++;
                }
            }
        ?>
        </tbody>
    </table>
    </div>
</body>
</html>