<?php
include("../connect.php");
session_start();
if(!isset($_SESSION['Email']))
{
   header("location:../login.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Customers</title>
    <?php include("../cdn.php");?>
    <style>
        body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f7f7f7;
}

header {
    background-color: maroon; 
    color: white;
    padding: 20px;
    text-align: center;
}

h1 {
    margin: 0;
}

.container-fluid {
    padding: 40px;
    display: flex;
    justify-content: center;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
    background-color: #fff;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
    overflow: hidden;
}

th, td {
    padding: 12px 15px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

th {
    background-color: maroon; 
    color: #fff;
}

tr:nth-child(even) {
    background-color: #f2f2f2;
}

tr:hover {
    background-color: #f1f1f1;
}

    </style>
   
</head>
<body>
<?php include("nav.php");?>
    <header>
        <h1>Our Customers</h1>
    </header>
    
    <div class="container-fluid">
        <table>
            <thead>
                <tr>
                    <th>Sr.no</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th>Password</th>
                    
                </tr>
            </thead>
            <tbody>
                <?php
                $sql ="select * from users";
                $res=mysqli_query($con,$sql);
                $sql1="select count(*) from users";
                if(mysqli_num_rows($res)>0) {
                    $i=1;
                    while($r=mysqli_fetch_array($res)) {
                        echo "<tr>";
                        echo "<td>" . $i . "</td>";
                        echo "<td>" . $r['Name'] . "</td>";
                        echo "<td>" . $r['Email'] . "</td>";
                        echo "<td>" . $r['Contact'] . "</td>";
                        echo "<td>" . $r['Password'] . "</td>";
                        echo "</tr>";
                        $i++;
                    }
                   
                }
                 else {
                    echo "<tr><td colspan='5'>No customers found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
            </div>
</body>
</html>
