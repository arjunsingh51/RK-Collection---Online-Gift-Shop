<?php
    include("../connect.php");
    session_start();
    if(!isset($_SESSION['Email']))
    {
       header("location:../login.php");
    }
    if(isset($_POST['sub']))
    {
        $cat=$_POST['cat'];
        $sql="insert into category(Category_name)values('$cat')";
        $res=mysqli_query($con,$sql);
        if($res)
        {
            $msg="Category Added";
            header("location:show-category.php");
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include("../cdn.php");?>
    <style>
        header {
    background-color: maroon; 
    color: #fff;
    padding: 20px;
    text-align: center;
}
h1 {
    margin: 0;
}
.login-form{
        border-radius:20px 20px;
        box-shadow:  0 8px 8px rgba(8, 4, 3, 0.1);
        
        overflow: hidden;
    background-color: #ffff;
    
}
      .login-form input {
    width: 100%;
    padding:10px;
    border: 1px solid black;
    border-radius: 5px;
}
    </style>
</head>
<body>
    <?php include("nav.php");?>
    <header><h1>Add Category</h1></header>
    <div class="container my-5">
        <div class="row d-flex justify-content-center">
            <div class="col-lg-5 col-12">
            <div class="login-form border  p-5 ">
            <form action="" method="post" class="form">
                <div class="form-group"><label for="">Category_name</label>
                <input type="text" id="" name="cat" class="form-control ">
                </div>
                <br>
                <button type="submit" name="sub" class="btn" style="background-color:maroon;color:White; width:100%;">Add</button><br>

            </form>
        </div>
            </div>
        </div>
        
    </div>
</body>
</html>