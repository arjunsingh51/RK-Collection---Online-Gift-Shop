<?php 
 include("../connect.php");
 session_start();
 if(!isset($_SESSION['Email']))
 {
    header("location:../login.php");
 }
 $email=$_SESSION['Email'];
 
 $sql = "SELECT * FROM users WHERE utype='admin' and email='$email'";
 $res = mysqli_query($con, $sql);
 if (mysqli_num_rows($res) > 0) {
     while ($r = mysqli_fetch_array($res)) {
            $img=$r['Image'];
            $name=$r['Name'];
            $contact=$r['Contact'];
            

     }
 }

if(isset($_POST['sub']))
    {
        $path="../profile-photo/".$_FILES['Image']['name'];
        $path1="profile-photo/".$_FILES['Image']['name'];
        $tem=$_FILES['Image']['tmp_name'];
        if(move_uploaded_file($tem,$path))
        {
            $sql="update users set Image='$path1' WHERE utype='admin'";
            $res=mysqli_query($con,$sql);
            if($res)
            {
                echo "<script>alert('change profile')</script>";
                header("location:dashboard.php");
            }
          
        }

    }
?>
  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <?php include("../cdn.php");?>
    <style>
             #wrapper {
            display: flex;
            transition: all 0.3s ease;
        }
        #sidebar-wrapper {
            width: 250px;
            background-color: #343a40;
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            transform: translateX(-250px);
            transition: transform 0.3s ease;
        }
        #page-content-wrapper {
            margin-left: 0;
            padding-left: 20px;
            width: 100%;
            transition: margin-left 0.3s ease;
        }
        #menu-toggle {
            display: none;
        }
        #menu-toggle:checked + #wrapper #sidebar-wrapper {
            transform: translateX(0);
        }
        #menu-toggle:checked + #wrapper #page-content-wrapper {
            margin-left: 250px;
        }
        .toggle-btn {
            display: inline-block;
            background-color:maroon;
            color: white;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
        }
        body {
    font-family: Arial, sans-serif;
   
    background-color: #f7f7f7;
}






        .container {
            display: flex;
            
            
        }

        .profile-container {
            display: flex;
            justify-content: space-between;
            background-color: #fff;
            padding: 10px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            border-radius: 20px 20px;
            width: 50%;
        }

        .profile-image {
            text-align: center;
            margin-right: 20px;
        }

        .profile-image img {
          height:50%;
          border:1px solid black;
        }

        .profile-details {
            flex-grow: 1;
        }

        .profile-details table {
            width: 100%;
        }

        .profile-details td {
            padding: 10px;
        }

        .profile-details th {
            text-align: left;
            padding: 10px;
            background-color: #f0f0f0;
        }

        .update-profile-btn {
            background-color: maroon;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }

        .update-profile-btn:hover {
            background-color: #a00;
        }

        .update-form input[type="file"] {
            padding: 10px;
            margin-top: 10px;
        }
        .card .card-body img{
            height:200px;
        }
        
    </style>
</head>
<body>

<input type="checkbox" id="menu-toggle" />

<div id="wrapper">

     <div id="sidebar-wrapper">
        <div class="sidebar-heading text-white p-3">Admin Dashboard</div>
        <div class="list-group list-group-flush">
            <a href="dashboard.php" class="list-group-item list-group-item-action bg-dark text-white">Dashboard</a>
            <a href="add-product.php" class="list-group-item list-group-item-action bg-dark text-white">Add Product</a>
            <a href="view-product.php" class="list-group-item list-group-item-action bg-dark text-white">View Product</a>
            <a href="view-customers.php" class="list-group-item list-group-item-action bg-dark text-white">View Customers</a>
            <a href="add-category.php" class="list-group-item list-group-item-action bg-dark text-white">Add Category</a>
            <a href="show-category.php" class="list-group-item list-group-item-action bg-dark text-white">Show Category</a>
            <a href="#" class="list-group-item list-group-item-action bg-dark text-white">Reports</a>
            <a href="logout.php" class="list-group-item list-group-item-action bg-dark text-white">Logout</a>
        </div>
    </div>
   <div id="page-content-wrapper">
        <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
            <label for="menu-toggle" class="toggle-btn" >Toggle Menu</label>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php"><b><i class='bx bxs-user'></i> ARJUN SINGH</b></a>
                    </li>
                </ul>
            </div>
        </nav>

        <div class="container-fluid p-4">
            <h1 class="mt-4 text-danger">WELCOME ARJUN</h1>
            <p>Welcome to the admin dashboard. Here you can manage users, view reports, and configure settings.</p>

            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-body">Total Users</div>
                        <div class="card-footer d-flex justify-content-between">
                            <span><?php
               $sql="select count(*) as total from users";
               $res=mysqli_query($con,$sql);
               if (mysqli_num_rows($res)>0) {
                    
                   while($r=mysqli_fetch_array($res)) {
                       echo $r['total'];
                       
                   }
                 
               }
                
                
                
                ?></span>
                            <span><a href="view-customers.php"  class="btn btn-light">View Details</a></span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="card bg-success text-white mb-4">
                        <div class="card-body">New Orders</div>
                        <div class="card-footer d-flex justify-content-between">
                            <span>45</span>
                            <span class="btn btn-light">View Details</span>
                        </div>
                    </div>
                    </div>
                <div class="col-lg-3 col-md-6">
                    <div class="card bg-warning text-white mb-4">
                        <div class="card-body">Pending Tasks</div>
                        <div class="card-footer d-flex justify-content-between">
                            <span>18</span>
                            <span  class="btn btn-light">View Details</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="card bg-danger text-white mb-4">
                        <div class="card-body">Issues Reported</div>
                        <div class="card-footer d-flex justify-content-between">
                            <span>5</span>
                            <span  class="btn btn-light">View Details</span>
                        </div>
                    </div>
                </div>
            </div>
       
<div class="container">
    <div class="row">
        <div class="col-lg-4 col-12">
               <div class="card">
                <div class="card-body">
                    <img src="../<?php if(isset($img)) echo $img ?>" class="d-block w-100 img-thumbnail border-danger" alt="" >
                    <form method="post" class="form" enctype="multipart/form-data">
                        <div class="form-group">
                            <input type="file" name="Image" class="form-control">
                        </div>
                        <div class="form-group ms-4">
                            <input type="submit" value="Update Profile" name="sub" class="btn" style="background-color:maroon;color:white;">
                        </div>
                    </form>
                </div>
               </div>
        </div>
        <div class="col-lg-8 col-sm-12 profile-details">
            <div class="card ">
            <header style="text-align:center; background-color:maroon; color:white;"><h3><b>About Me</b></h3></header>
                <div class="card-body">
                <table class="table ">
                <tr>
                    <th>Name</th>
                    <td><?php if(isset($name)) echo $name ?></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><?php if(isset($email)) echo $email ?></td>
                </tr>
                <tr>
                    <th>Contact</th>
                    <td><?php if(isset($contact)) echo $contact ?></td>
                </tr>
                <tr>
                    <th>Address</th>
                    <td>Akbarpur keshorai Alipur Alignj Etah</td>
                </tr>
            </table>

                </div>
            </div>
       
        </div>
    </div>
</div>
            </div>
            </div>
    </div>

</div>            
</body>
</html>