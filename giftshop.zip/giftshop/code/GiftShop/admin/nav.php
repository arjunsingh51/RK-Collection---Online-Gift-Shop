<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include("../cdn.php");?>
    <style>
           #wrapper {
            display: flex;
            min-height: ;
            transition: all 0.3s ease;
        }
        #sidebar-wrapper {
            width: 250px;
            background-color: #343a40;
            position:fixed;
            top: 0;
            left: 0;
            height: 100vh;
            transform: translateX(-250px);
            transition: transform 0.3s ease;
        }
        #page-content-wrapper {
            margin-left: 0;
            padding-left: 20px;
            width: 100%;
            transition: margin-left 0.3s ease;
        }
        #menu-toggle {
            display: none;
        }
        #menu-toggle:checked + #wrapper #sidebar-wrapper {
            transform: translateX(0);
        }
        #menu-toggle:checked + #wrapper #page-content-wrapper {
            margin-left: 250px;
        }
        .toggle-btn {
            display: inline-block;
            background-color: maroon;
            color: white;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>
</head>
<body>
<input type="checkbox" id="menu-toggle" />

<div id="wrapper">
     <div id="sidebar-wrapper">
        <div class="sidebar-heading text-white p-3">Admin Dashboard</div>
        <div class="list-group list-group-flush">
            <a href="dashboard.php" class="list-group-item list-group-item-action bg-dark text-white">Dashboard</a>
            <a href="add-product.php" class="list-group-item list-group-item-action bg-dark text-white">Add Product</a>
            <a href="view-product.php" class="list-group-item list-group-item-action bg-dark text-white">View Product</a>
            <a href="view-customers.php" class="list-group-item list-group-item-action bg-dark text-white">View Customers</a>
            <a href="add-category.php" class="list-group-item list-group-item-action bg-dark text-white">Add Category</a>
            <a href="show-category.php" class="list-group-item list-group-item-action bg-dark text-white">Show Category</a>
            <a href="#" class="list-group-item list-group-item-action bg-dark text-white">Reports</a>
            <a href="logout.php" class="list-group-item list-group-item-action bg-dark text-white">Logout</a>
        </div>
    </div>
   <div id="page-content-wrapper">
        <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
            <label for="menu-toggle" class="toggle-btn">Toggle Menu</label>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php"><b><i class='bx bxs-user'></i> ARJUN SINGH</b></a>
                    </li>
                </ul>
            </div>
        </nav>
</body>
</html>