<?php
include("../connect.php");
session_start();
if(!isset($_SESSION['Email']))
{
   header("location:../login.php");
}
    $id=$_GET['id'];
    $sql="delete from product where id='$id'";
    $res=mysqli_query($con,$sql);
    if($res)
    {
        header("location:view-product.php");
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>