<?php
  include("../connect.php");
  session_start();
  if(!isset($_SESSION['Email'])) {
      header("location:../login.php");
  }
  if(isset($_GET['id'])){
    $id = $_GET['id'];
    $id = mysqli_real_escape_string($con, $id);
    $sql = "SELECT * FROM product WHERE id='$id'";
    $res = mysqli_query($con, $sql);

    if(mysqli_num_rows($res) > 0){
      while($r = mysqli_fetch_assoc($res)){
        $Name = $r['Name'];
        $Image = $r['Image']; 
        $Price = $r['Price']; 
        $Description = $r['Description']; 
      }
    } else {
      echo "Product not found.";
      exit();
    }
  } else {
    echo "No product ID specified.";
    exit();
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product View</title>

    <?php include("../cdn.php"); ?>
    <style>
        .container {
            display: flex;
           
        }
        .card{
            height:;
        }

        .product-image {
            width: 100%;
            max-width: 500px;
            height: auto;
            object-fit: cover;
            margin-bottom: ;
        }

        .product-image-container {
            flex-basis:50%;
            height:auto;
            border-radius:15px 15px;
        }

        .product-details {
            flex-basis: 45%;
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }

        .product-name {
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .product-price {
            font-size: 1.5rem;
            color: #28a745;
            font-weight: 600;
            margin-bottom: 20px;
        }

        .product-description {
            font-size: 1rem;
            margin-top: 20px;
            margin-bottom: 20px;
            line-height: 1.6;
            color: #333;
        }

        .product-buttons {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-top: 20px;
        }

        .btn {
            font-size: 1rem;
            padding: 10px 20px;
            border-radius: 5px;
        }

        .btn-outline-primary {
            border: 1px solid #007bff;
            background-color: transparent;
            color: #007bff;
        }

        .btn-outline-danger {
            border: 1px solid #dc3545;
            background-color: transparent;
            color: #dc3545;
        }

        .quantity-container {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .quantity-input {
            width: 60px;
            padding: 5px;
            text-align: center;
            font-size: 1.2rem;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        
    </style>
</head>
<body>
    <?php include("header.php"); ?>

    <div class="container">
        <div class="product-image-container">
            <img src="../<?php echo $Image; ?>" alt="Product Image" class="product-image">
        </div>
        <div class="product-details">
            <div class="product-name">
                <?php if(isset($Name)) echo $Name; ?>
            </div>
            <div class="product-price">
                <?php if(isset($Price)) echo "<i class='bx bx-rupee'></i>" . number_format($Price, 2); ?>
            </div>
            <div class="quantity-container">
                <button class="btn btn-outline-primary" onclick="decreaseQuantity()">-</button>
                <input type="number" id="quantity" name="quantity" class="quantity-input" value="1" min="1">
                <button class="btn btn-outline-primary" onclick="increaseQuantity()">+</button>
            </div>
            
            <div class="product-buttons">
            <a href="login.php" class="btn btn-outline-danger">Buy Now</a>
                <form action="cart.php" method="post">
                    <input type="hidden" name="Name" value="<?php echo $Name; ?>">
                    <input type="hidden" name="Image" value="<?php echo $Image; ?>"/>
                    <input type="hidden" name="Price" value="<?php echo $Price; ?>">
                    <input type="hidden" name="Quantity" id="cartQuantity" value="1"/>
                    <button type="submit" class="btn btn-danger ms-5"><i class="bx bxs-cart-add"></i> Add To Cart</button>
                </form>
            </div>
            <hr>
            <div class="product-description">
                <h3>Description</h3>
                <?php if(isset($Description)) echo $Description; ?>
            </div>
        </div>
    </div>
    <script>
        function increaseQuantity() {
            var quantity = document.getElementById("quantity");
            quantity.value = parseInt(quantity.value) + 1;
            document.getElementById("cartQuantity").value = quantity.value;
        }

        function decreaseQuantity() {
            var quantity = document.getElementById("quantity");
            if (quantity.value > 1) {
                quantity.value = parseInt(quantity.value) - 1;
                document.getElementById("cartQuantity").value = quantity.value;
            }
        }
    </script>
    <div class="container-fluid pro my-3">
      <h3 style="text-align:center; color:maroon; ">SUGGESTIONS</h3>
      <div class="row">
         <div class="col-12 d-flex justify-content-end">
            <a href="birthday.php" style="color:maroon;" class="btn">View More</a>
         </div>
      </div>
      <div class="row p">
         <?php
           $sql="select * from product where Category='birthday' order by id desc limit 4";
           $res=mysqli_query($con,$sql);
           if(mysqli_num_rows($res)>0)
           {
            while($r=mysqli_fetch_assoc($res))
            {
               echo' 
                  <div class="col-lg-3 col-md-6 col-sm-12"> 
                     <div class="card">
                     <a href="description.php?id='.$r['id'].'" style="text-decoration:none;color:black;">
                        <form action="cart.php" method="post">
                              <input type="hidden" name="Name" value="'.$r['Name'].'">
                              <input type="hidden" name="Image" value="'.$r['Image'].'"/>
                              <input type="hidden" name="Price" value="'.$r['Price'].'">
                              <input type="hidden" name="Quantity" value="1"/>
                               <div class="card-header">
                                <img src="../'.$r['Image'].'" class="img d-block w-100"></div>
                               <div class="card-body">
                                <h4>'.$r['Name'].'</h4>
                                <h6>'.$r['Price'].'</h6>
                               </div>
                               <div class="card-footer">
                                <a href="login.php" class="btn btn-outline-danger">Buy</a>
                               <button type="submit" class="btn btn-danger ms-5"><i class="bx bxs-cart-add"></i>Add To Cart</button>
                               </div>
                        </form>
                        </a>
                     </div>
                  </div>
                     
               ';
            }
           }
         ?>
      </div>
   </div>
    <?php include("footer.php"); ?>
</body>
</html>
