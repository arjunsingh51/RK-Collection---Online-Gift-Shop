<?php
include("../connect.php");
    session_start();
    if(!isset($_SESSION['cart']))
    {
        $_SESSION['cart']=[];
    }
    $Name=$_POST['Name'];
    $Image=$_POST['Image'];
    $Price=$_POST['Price'];
    $Quantity=$_POST['Quantity'];
    if($_SESSION['cart'][$Name])
    {
        $_SESSION['cart'][$Name]['Quantity']+=1;
    }
    else
    {
        $_SESSION['cart'][$Name]=['Name'=>$Name,'Image'=>$Image,'Price'=>$Price,'Quantity'=>$Quantity];
    }
    echo "<script>
    alert('Product Added ');
        window.location='check-cart.php';
    </script>";
?>

