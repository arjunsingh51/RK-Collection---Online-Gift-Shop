<?php
include("../connect.php");
 
session_start();
if(!isset($_SESSION['Email'])) {
   header("location:../login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RK Collection</title>
    <link rel="logo" href="../img3.jpg"/>
   <?php include("../cdn.php");?>
   <style>
      .pro{
         border-radius:14px 14px;
         margin-top:20px;
         padding:10px;
      }
     
   </style>
   <?php include("header.php");?>
   
</head>
<body>
   <div class="carousel slide" data-bs-ride="carousel true" data-bs-interval="3000" id="carouselExampleRide">
        <div class="carousel-inner">
            <div class="carousel-item active">
               <a href="occasions.php"> <img src="../img9.jpg" alt="banner" class="d-block w-100" height="400"></a>
            </div>
                <div class="carousel-item">
                   <a href="wedding-gifts.php"> <img src="../img8.webp" alt="banner" class="d-block w-100" height="400"></a>
                </div>
                <div class="carousel-item">
                   <a href="on-trend.php"> <img src="../img7.jpg" alt="banner" class="d-block w-100" height="400"></a>
                </div>
                <div class="carousel-item">
                   <a href="on-trend.php"><img src="../img6.avif" alt="banner" class="d-block w-100" height="400"></a> 
                </div>
                <div class="carousel-item">
                   <a href="anniversary.php"> <img src="../img5.png" alt="banner" class="d-block w-100" height="400"></a>
                </div>
        </div>
        <button class="carousel-control-prev " type="button" data-bs-target="#carouselExampleRide" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button class="carousel-control-next " type="button" data-bs-target="#carouselExampleRide" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
   </div>
   <div class="container-fluid pro">
      <h3 style="text-align:center; color:maroon;">BIRTHDAY GIFTS</h3>
      <div class="row">
         <div class="col-12 d-flex justify-content-end">
            <a href="birthday.php" style="color:maroon;" class="btn">View More</a>
         </div>
      </div>
      <div class="row p">
         <?php
           $sql="select * from product where Category='birthday' order by id desc limit 4";
           $res=mysqli_query($con,$sql);
           if(mysqli_num_rows($res)>0)
           {
            while($r=mysqli_fetch_assoc($res))
            {
               echo' 
                  <div class="col-lg-3 col-md-6 col-sm-12"> 
                     <div class="card">
                     <a href="description.php?id='.$r['id'].'" style="text-decoration:none;color:black;">
                        <form action="cart.php" method="post">
                              <input type="hidden" name="Name" value="'.$r['Name'].'">
                              <input type="hidden" name="Image" value="'.$r['Image'].'"/>
                              <input type="hidden" name="Price" value="'.$r['Price'].'">
                              <input type="hidden" name="Quantity" value="1"/>
                               <div class="card-header">
                                <img src="../'.$r['Image'].'" class="img d-block w-100"></div>
                               <div class="card-body">
                                <h4>'.$r['Name'].'</h4>
                                <h6>'.$r['Price'].'</h6>
                               </div>
                               <div class="card-footer">
                                <a href="#" class="btn btn-outline-danger">Buy</a>
                               <button type="submit" class="btn btn-danger ms-5"><i class="bx bxs-cart-add"></i>Add To Cart</button>
                               </div>
                        </form>
                        </a>
                     </div>
                  </div>
                     
               ';
            }
           }
         ?>
      </div>
   </div>
   <div class="container-fluid pro">
      <h3 style="text-align:center; color:maroon;">ANNIVERSARY GIFTS</h3>
      <div class="row">
         <div class="col-12 d-flex justify-content-end">
            <a href="birthday.php" style="color:maroon;" class="btn">View More</a>
         </div>
      </div>
      <div class="row p">
         <?php
           $sql="select * from product where Category='anniversary' order by id desc limit 4";
           $res=mysqli_query($con,$sql);
           if(mysqli_num_rows($res)>0)
           {
            while($r=mysqli_fetch_assoc($res))
            {
               echo' 
                  <div class="col-lg-3 col-md-6 col-sm-12"> 
                     <div class="card">
                     <a href="description.php?id='.$r['id'].'" style="text-decoration:none;color:black;">
                        <form action="cart.php" method="post">
                              <input type="hidden" name="Name" value="'.$r['Name'].'">
                              <input type="hidden" name="Image" value="'.$r['Image'].'"/>
                              <input type="hidden" name="Price" value="'.$r['Price'].'">
                              <input type="hidden" name="Quantity" value="1"/>
                               <div class="card-header">
                                <img src="../'.$r['Image'].'" class="img d-block w-100"></div>
                               <div class="card-body">
                                <h4>'.$r['Name'].'</h4>
                                <h6>'.$r['Price'].'</h6>
                               </div>
                               <div class="card-footer">
                                <a href="#" class="btn btn-outline-danger">Buy</a>
                               <button type="submit" class="btn btn-danger ms-5""><i class="bx bxs-cart-add"></i>Add To Cart</button>
                               </div>
                        </form>
                        </a>
                     </div>
                  </div>
                     
               ';
            }
           }
         ?>
      </div>
   </div>
   <div class="container-fluid pro">
      <h3 style="text-align:center; color:maroon;">WEDDING GIFTS</h3>
      <div class="row">
         <div class="col-12 d-flex justify-content-end">
            <a href="birthday.php" style="color:maroon;" class="btn">View More</a>
         </div>
      </div>
      <div class="row p">
         <?php
           $sql="select * from product where Category='wedding' order by id desc limit 4";
           $res=mysqli_query($con,$sql);
           if(mysqli_num_rows($res)>0)
           {
            while($r=mysqli_fetch_assoc($res))
            {
               echo' 
                  <div class="col-lg-3 col-md-6 col-sm-12"> 
                     <div class="card">
                     <a href="description.php?id='.$r['id'].'" style="text-decoration:none;color:black;">
                        <form action="cart.php" method="post">
                              <input type="hidden" name="Name" value="'.$r['Name'].'">
                              <input type="hidden" name="Image" value="'.$r['Image'].'"/>
                              <input type="hidden" name="Price" value="'.$r['Price'].'">
                              <input type="hidden" name="Quantity" value="1"/>
                               <div class="card-header">
                                <img src="../'.$r['Image'].'" class="img d-block w-100"></div>
                               <div class="card-body">
                                <h4>'.$r['Name'].'</h4>
                                <h6>'.$r['Price'].'</h6>
                               </div>
                               <div class="card-footer">
                                <a href="#" class="btn btn-outline-danger">Buy</a>
                               <button type="submit" class="btn btn-danger ms-5""><i class="bx bxs-cart-add"></i>Add To Cart</button>
                               </div>
                        </form>
                        </a>
                     </div>
                  </div>
                     
               ';
            }
           }
         ?>
      </div>
   </div>
   <div class="container-fluid pro">
      <h3 style="text-align:center; color:maroon;">TOYS</h3>
      <div class="row">
         <div class="col-12 d-flex justify-content-end">
            <a href="birthday.php" style="color:maroon;" class="btn">View More</a>
         </div>
      </div>
      <div class="row p">
         <?php
           $sql="select * from product where Category='toys' order by id desc limit 4";
           $res=mysqli_query($con,$sql);
           if(mysqli_num_rows($res)>0)
           {
            while($r=mysqli_fetch_assoc($res))
            {
               echo' 
                  <div class="col-lg-3 col-md-6 col-sm-12"> 
                     <div class="card">
                     <a href="description.php?id='.$r['id'].'" style="text-decoration:none;color:black;">
                        <form action="cart.php" method="post">
                              <input type="hidden" name="Name" value="'.$r['Name'].'">
                              <input type="hidden" name="Image" value="'.$r['Image'].'"/>
                              <input type="hidden" name="Price" value="'.$r['Price'].'">
                              <input type="hidden" name="Quantity" value="1"/>
                               <div class="card-header">
                                <img src="../'.$r['Image'].'" class="img d-block w-100"></div>
                               <div class="card-body">
                                <h4>'.$r['Name'].'</h4>
                                <h6>'.$r['Price'].'</h6>
                               </div>
                               <div class="card-footer">
                                <a href="#" class="btn btn-outline-danger">Buy</a>
                               <button type="submit" class="btn btn-danger ms-5""><i class="bx bxs-cart-add"></i>Add To Cart</button>
                               </div>
                        </form>
                        </a>
                     </div>
                  </div>
                     
               ';
            }
           }
         ?>
      </div>
   </div>
   <div class="container-fluid pro">
      <h3 style="text-align:center; color:maroon;">DECORATION</h3>
      <div class="row">
         <div class="col-12 d-flex justify-content-end">
            <a href="birthday.php" style="color:maroon;" class="btn">View More</a>
         </div>
      </div>
      <div class="row p">
         <?php
           $sql="select * from product where Category='decoration' order by id desc limit 4";
           $res=mysqli_query($con,$sql);
           if(mysqli_num_rows($res)>0)
           {
            while($r=mysqli_fetch_assoc($res))
            {
               echo' 
                  <div class="col-lg-3 col-md-6 col-sm-12"> 
                     <div class="card">
                     <a href="description.php?id='.$r['id'].'" style="text-decoration:none;color:black;">
                        <form action="cart.php" method="post">
                              <input type="hidden" name="Name" value="'.$r['Name'].'">
                              <input type="hidden" name="Image" value="'.$r['Image'].'"/>
                              <input type="hidden" name="Price" value="'.$r['Price'].'">
                              <input type="hidden" name="Quantity" value="1"/>
                               <div class="card-header">
                                <img src="../'.$r['Image'].'" class="img d-block w-100"></div>
                               <div class="card-body">
                                <h4>'.$r['Name'].'</h4>
                                <h6>'.$r['Price'].'</h6>
                               </div>
                               <div class="card-footer">
                                <a href="#" class="btn btn-outline-danger">Buy</a>
                               <button type="submit" class="btn btn-danger ms-5""><i class="bx bxs-cart-add"></i>Add To Cart</button>
                               </div>
                        </form>
                        </a>
                     </div>
                  </div>
                     
               ';
            }
           }
         ?>
      </div>
   </div>
   <div class="container-fluid pro">
      <h3 style="text-align:center; color:maroon;">TRENDING GIFTS</h3>
      <div class="row">
         <div class="col-12 d-flex justify-content-end">
            <a href="birthday.php" style="color:maroon;" class="btn">View More</a>
         </div>
      </div>
      <div class="row p">
         <?php
           $sql="select * from product where Category='on trend' order by id desc limit 4";
           $res=mysqli_query($con,$sql);
           if(mysqli_num_rows($res)>0)
           {
            while($r=mysqli_fetch_assoc($res))
            {
               echo' 
                  <div class="col-lg-3 col-md-6 col-sm-12"> 
                     <div class="card">
                     <a href="description.php?id='.$r['id'].'" style="text-decoration:none;color:black;">
                        <form action="cart.php" method="post">
                              <input type="hidden" name="Name" value="'.$r['Name'].'">
                              <input type="hidden" name="Image" value="'.$r['Image'].'"/>
                              <input type="hidden" name="Price" value="'.$r['Price'].'">
                              <input type="hidden" name="Quantity" value="1"/>
                               <div class="card-header">
                                <img src="../'.$r['Image'].'" class="img d-block w-100"></div>
                               <div class="card-body">
                                <h4>'.$r['Name'].'</h4>
                                <h6>'.$r['Price'].'</h6>
                               </div>
                               <div class="card-footer">
                                <a href="#" class="btn btn-outline-danger">Buy</a>
                               <button type="submit" class="btn btn-danger ms-5""><i class="bx bxs-cart-add"></i>Add To Cart</button>
                               </div>
                        </form>
                        </a>
                     </div>
                  </div>
                     
               ';
            }
           }
         ?>
      </div>
   </div>
   <div class="container-fluid pro">
      <h3 style="text-align:center; color:maroon;">FESTIVAL GIFTS</h3>
      <div class="row">
         <div class="col-12 d-flex justify-content-end">
            <a href="birthday.php" style="color:maroon;" class="btn">View More</a>
         </div>
      </div>
      <div class="row p">
         <?php
           $sql="select * from product where Category='Festival' order by id desc limit 4";
           $res=mysqli_query($con,$sql);
           if(mysqli_num_rows($res)>0)
           {
            while($r=mysqli_fetch_assoc($res))
            {
               echo' 
                  <div class="col-lg-3 col-md-6 col-sm-12"> 
                     <div class="card">
                     <a href="description.php?id='.$r['id'].'" style="text-decoration:none;color:black;">
                        <form action="cart.php" method="post">
                              <input type="hidden" name="Name" value="'.$r['Name'].'">
                              <input type="hidden" name="Image" value="'.$r['Image'].'"/>
                              <input type="hidden" name="Price" value="'.$r['Price'].'">
                              <input type="hidden" name="Quantity" value="1"/>
                               <div class="card-header">
                                <img src="../'.$r['Image'].'" class="img d-block w-100"></div>
                               <div class="card-body">
                                <h4>'.$r['Name'].'</h4>
                                <h6>'.$r['Price'].'</h6>
                               </div>
                               <div class="card-footer">
                                <a href="#" class="btn btn-outline-danger">Buy</a>
                               <button type="submit" class="btn btn-danger ms-5""><i class="bx bxs-cart-add"></i>Add To Cart</button>
                               </div>
                        </form>
                        </a>
                     </div>
                  </div>
                     
               ';
            }
           }
         ?>
      </div>
   </div>
   <div class="container-fluid pro">
      <h3 style="text-align:center; color:maroon;">OCCASIONS</h3>
      <div class="row">
         <div class="col-12 d-flex justify-content-end">
            <a href="birthday.php" style="color:maroon;" class="btn">View More</a>
         </div>
      </div>
      <div class="row p">
         <?php
           $sql="select * from product where Category='occasions' order by id desc limit 4";
           $res=mysqli_query($con,$sql);
           if(mysqli_num_rows($res)>0)
           {
            while($r=mysqli_fetch_assoc($res))
            {
               echo' 
                  <div class="col-lg-3 col-md-6 col-sm-12"> 
                     <div class="card">
                     <a href="description.php?id='.$r['id'].'" style="text-decoration:none;color:black;">
                        <form action="cart.php" method="post">
                              <input type="hidden" name="Name" value="'.$r['Name'].'">
                              <input type="hidden" name="Image" value="'.$r['Image'].'"/>
                              <input type="hidden" name="Price" value="'.$r['Price'].'">
                              <input type="hidden" name="Quantity" value="1"/>
                               <div class="card-header">
                                <img src="../'.$r['Image'].'" class="img d-block w-100"></div>
                               <div class="card-body">
                                <h4>'.$r['Name'].'</h4>
                                <h6>'.$r['Price'].'</h6>
                               </div>
                               <div class="card-footer">
                                <a href="#" class="btn btn-outline-danger">Buy</a>
                               <button type="submit" class="btn btn-danger ms-5""><i class="bx bxs-cart-add"></i>Add To Cart</button>
                               </div>
                        </form>
                        </a>
                     </div>
                  </div>
                     
               ';
            }
           }
         ?>
      </div>
   </div>
    
<?php include("footer.php");?>
</body>
</html>
