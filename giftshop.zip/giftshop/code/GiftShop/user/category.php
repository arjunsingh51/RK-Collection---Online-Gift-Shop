<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
   <?php include("../cdn.php");?>
    <style>
         .category{
        background-color:maroon;
        
    }
    .collaps .nav-item{
        justify-content:space-between;
        text-align:center;
        text:bold;
        margin-left:65px;
        position:relative;
        
    }
    .collaps .nav-link{
        color:white;
    }
    .category .nav-link:hover{
        background-color:white;
        transition: 0.5s;
        border-radius: 15px;
        box-shadow: 2px 2px 2px 0px;
    
        background: transparent;
        color:white;
    }

    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light category">
<div class="container-fluid">
          
            <button class="navbar-toggler" data-bs-toggle="collaps" data-bs-target="#navy" aria-controls="navy" aria-expanded="false">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="navbar-collapse collaps" id="navy">
                <ul class="navbar-nav "> 
                    <li class="nav-item">
                        <a href="birthday.php" class="nav-link">BIRTHDAY</a>
                    </li>
                    <li class="nav-item">
                        <a href="anniversary.php" class="nav-link">ANNIVERSARY</a>
                    </li>
                    <li class="nav-item">
                        <a href="wedding-gifts.php" class="nav-link">WEDDINGS</a>
                    </li>
                    <li class="nav-item">
                        <a href="toys.php" class="nav-link">TOYS</a>
                    </li>
                    <li class="nav-item">
                        <a href="occasions.php" class="nav-link">OCCASIONS</a>
                    </li>
                    <li class="nav-item">
                        <a href="on-trend.php" class="nav-link">ON TREND</a>
                    </li>
                    <li class="nav-item">
                        <a href="decoration.php" class="nav-link">DECORATION</a>
                    </li>
                    <li class="nav-item">
                        <a href="festival-gifts.php" class="nav-link">FESTIVALS</a>
                    </li>
                    </ul>
                
            </div>
        </div>
   

</nav>
</body>
</html>