<?php 
include("../connect.php");
session_start();
if(!isset($_SESSION['Email'])) {
    header("location:../login.php");
}
$email = $_SESSION['Email'];
$sql = "SELECT * FROM users WHERE utype='user' AND email='$email'";
$res = mysqli_query($con, $sql);
if (mysqli_num_rows($res) > 0) {
    $r = mysqli_fetch_array($res);
    $id = $r['id'];
    $img = isset($r['Image']) ? $r['Image'] : '';  
    $name = $r['Name'];
    $contact = $r['Contact'];
    $address = $r['Address'];
}
if (isset($_POST['sub'])) {
    $name = $_POST['Name'];
    $contact = $_POST['Contact'];
    $address = $_POST['Address'];
    
    if ($_FILES['Image']['name']) {
        $path = "../profile-photo/" . $_FILES['Image']['name'];
        $path1 = "profile-photo/" . $_FILES['Image']['name'];
        $tem = $_FILES['Image']['tmp_name'];
        if (move_uploaded_file($tem, $path)) {
            $sql = "UPDATE users SET Image='$path1', Name='$name', Contact='$contact', Address='$address' WHERE id='$id'";
            $res = mysqli_query($con, $sql);
            if ($res) {
                echo "<script>alert('Profile updated successfully')</script>";
                header("location:profile.php");
            }
        }
    } else {
        $sql = "UPDATE users SET Name='$name', Contact='$contact', Address='$address' WHERE id='$id'";
        $res = mysqli_query($con, $sql);
        if ($res) {
            echo "<script>alert('Profile updated successfully')</script>";
            header("location:profile.php");
        }
    }
}
if (isset($_POST['logout'])) {
    session_destroy();
    header("location:../login.php");
}
?>
  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <?php include("../cdn.php"); ?>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
        }

        .container {
            display: flex;
            margin-bottom:40px;
        }

        .profile-container {
            display: flex;
            justify-content: space-between;
            background-color: #fff;
            padding: 10px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            border-radius: 20px 20px;
            width: 50%;
        }

        .profile-image {
            text-align: center;
            margin-right: 20px;
        }

        .profile-image img {
            height: 50%;
            border: 1px solid black;
        }

        .profile-details {
            flex-grow: 1;
        }

        .profile-details table {
            width: 100%;
        }

        .profile-details td {
            padding: 10px;
        }

        .profile-details th {
            text-align: left;
            padding: 10px;
            background-color: #f0f0f0;
        }

        .update-profile-btn {
            background-color: maroon;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }

        .update-profile-btn:hover {
            background-color: #a00;
        }

        .update-form input[type="file"] {
            padding: 10px;
            margin-top: 10px;
        }

        .logout-btn, .order-btn {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            margin-top: 10px;
        }

        .logout-btn:hover, .order-btn:hover {
            background-color: #0056b3;
        }
    </style>
    <?php include("header.php"); ?>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-12">
                <div class="card">
                    <div class="card-body">
                        <img src="../<?php echo $img ? $img : 'profile-photo/default.jpg'; ?>" class="d-block w-100 img-thumbnail border-danger" alt="">
                        <form method="post" class="form" enctype="multipart/form-data">
                            <div class="form-group">
                                <input type="file" name="Image" class="form-control">
                            </div>
                            <div class="form-group ms-4">
                                <input type="submit" value="Update Profile" name="sub" class="btn" style="background-color:maroon;color:white;">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 col-sm-12 profile-details">
                <div class="card">
                    <header style="text-align:center; background-color:maroon; color:white;">
                        <h3><b>About Me</b></h3>
                    </header>
                    <div class="card-body">
                        <form method="POST">
                            <table class="table">
                                <tr>
                                    <th>Name</th>
                                    <td><input type="text" name="Name" value="<?php if (isset($name)) echo $name ?>" class="form-control"></td>
                                </tr>
                                <tr>
                                    <th>Email</th>
                                    <td><input type="text" name="Email" value="<?php if (isset($email)) echo $email ?>" class="form-control" disabled></td>
                                </tr>
                                <tr>
                                    <th>Contact</th>
                                    <td><input type="text" name="Contact" value="<?php if (isset($contact)) echo $contact ?>" class="form-control"></td>
                                </tr>
                                <tr>
                                    <th>Address</th>
                                    <td><textarea name="Address" class="form-control"><?php if (isset($address)) echo $address ?></textarea></td>
                                </tr>
                            </table>
                            <input type="submit" name="sub" value="Update Profile" class="update-profile-btn">
                        </form>
                        <form method="POST">
                            <input type="submit" name="logout" value="Logout" class="logout-btn"> 
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include("footer.php");?>
</body>
</html>
