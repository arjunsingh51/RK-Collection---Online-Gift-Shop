<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script>
            function show()
            {
                setTimeout("show1()",2000);
            }
            function show1()
            {
                window.location="home.php";
            }

    </script>
</head>
<body onload="show()">
    <h1>You Have Successfully Ordered</h1>
</body>
</html>