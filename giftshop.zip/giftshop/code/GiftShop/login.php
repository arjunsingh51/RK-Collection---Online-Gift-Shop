<?php
   
    session_start();
    error_reporting(0);
    include("connect.php");
    if(isset($_POST['sub']))
    {
        $Email=$_POST['Email'];
        $Password=$_POST['Password'];
        $sql="select utype from users where Email='$Email' and Password='$Password'";
        $res=mysqli_query($con,$sql);
        if(mysqli_num_rows($res)>0)
        {
            $_SESSION['Email']=$Email;
            while($r=mysqli_fetch_assoc($res))
            {
                $ut=$r['utype'];
                if($ut=='admin')
                {
                    header("location:admin/dashboard.php");
                }
                else{
                    header("location:user/home.php");
                }
            }
        } 
        else{
           echo "<script>alert('Invalid Password')</script>";
        }       
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <?php include("cdn.php");?>
    <style>
         body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    height:100vh;
    background-color: #f7f7f7;
    background:url(https://cdn.igp.com/raw/upload/assets/svg-icons/rebrand-login-ill.svg);
    background-repeat:no-repeat;
    background-size:cover;
         }
      .login-form{
        border-radius:20px 20px;
        box-shadow:  0 8px 8px rgba(8, 4, 3, 0.1);
        
        overflow: hidden;
    background-color: #ffff;
    
      }
      h2{
        justify-content:center;
        text-align:center;
      }
      .login-form input {
    width: 100%;
    padding:10px;
    border: 1px solid black;
    border-radius: 5px;
}

     
    </style>
    
</head>
<body>
    <?php include("header.php");?>
    <div class="container my-5">
        <div class="row d-flex justify-content-center">
            <div class="col-lg-5 col-12">
            <div class="login-form border  p-5 ">
            <h2 style="color:maroon;">Login</h2>
            <form action="" method="post" class="form">
                <div class="form-group"><label for="Email">Email</label>
                <input type="Email" id="" name="Email" class="form-control ">
                </div>
                <div class="form-group">
                <label for="Password">Password</label>
                <input type="password" id="password" name="Password" class="form-control " required>
                </div>
                <br>
                <button type="submit" name="sub" class="btn" style="background-color:maroon;color:White; width:100%;">Login</button><br>

                <a href="reset-password.php" style="color:red;">Forgot Password</a>
                <p style="color:black;">Don't have an account? <a href="register.php" style="color:red;">Register</a></p>

            </form>
        </div>
            </div>
        </div>
        
    </div>
    <?php include("footer.php");?>
</body>
</html>
