<?php 

    session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
    .navbar .nav-link
    {
        color:white;
    }
    .card .card-header img{
        height: 200px;
    }
    .table{
        margin-top:40px;
    }
    .order{
        display:flex;
    }
</style>
</head>
<body>
    <?php include("header.php");?>
   <div>
    <h1 style="text-align:center; color:black; padding:20px;">Shopping Cart</h1>
   </div>
    <table class="table table-string table-bordered table-hover ">
        <thead>
            <th style="color:white; background-color:maroon;">Product Name</th>
            <th style="color:white; background-color:maroon;">Product Image</th>
            <th style="color:white; background-color:maroon;">Price</th>
            <th style="color:white; background-color:maroon;">Quantity</th>
            <th style="color:white; background-color:maroon;">Total</th>
            <th style="color:white; background-color:maroon;">Action</th>
        </thead>
        <tbody>
        <?php
if (isset($_GET['remove'])) {
    $removeId = $_GET['remove'];
    if (isset($_SESSION['cart'][$removeId])) {
       
        unset($_SESSION['cart'][$removeId]);
    }
}
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    echo "<tr><td colspan='5'><h3>No Product Added In Cart</h3> <a href='home.php' class='btn' style='color:white; background-color:maroon;'>Continue Shopping</a></td></tr>";
    exit;
} else {
    $totalAmount = 0;
    foreach ($_SESSION['cart'] as $id => $p) {
        $Price = isset($p['Price']) ? floatval($p['Price']) : 0; 
        $Quantity = isset($p['Quantity']) ? intval($p['Quantity']) : 0; 
        $total = $Price * $Quantity; 
        $totalAmount += $total;
        
        echo "
            <tr>
                <td>".$p['Name']."</td>
                <td><img src='".$p['Image']."' height='50px'/></td>
                <td>".$Price."</td>
                <td>".$Quantity."</td>
                <td>".$total."</td>
                <td><a href='?remove=".$id."' class='btn' style='background-color:maroon; color:white;'>Remove</a></td>
            </tr>
        ";
    }
    
    echo "<tr>
        <td colspan='5' align='right'>Total Amount: ".$totalAmount."</td>
    </tr>";
}
?>

        </tbody>
    </table>
    <div class="my-5 order">
    <a href="home.php" class="btn" style="color:white; background-color:maroon;">Continue Shopping</a>
    <a href="login.php" class="btn ms-auto" style="color:white; background-color:maroon;">Check Out</a>
    </div>
    <?php include("footer.php");?>
</body>
</html>