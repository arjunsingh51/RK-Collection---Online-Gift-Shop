<?php
 include("connect.php");
    if(isset($_POST['sub']))
    {
       
        $Name=$_POST['Name'];
        $Email=$_POST['Email'];
        $Contact=$_POST['Contact'];
        $Password=$_POST['Password'];
        $sql="insert into users(Name,Email,Contact,Password,utype)values('$Name','$Email','$Contact','$Password','user')";
         $res=mysqli_query($con,$sql);
         if($res)
        {
        $msg="Registration done";
        header("location:login.php");
         }
       

        
       
       
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <title>REGISTER</title>
    <?php include("cdn.php");?>
    
    <style>
 body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    height:100vh;
    background:url(https://cdn.igp.com/raw/upload/assets/svg-icons/rebrand-login-ill.svg);
    background-repeat: no-repeat;
    background-size: cover;
}
.login-form{
        border-radius:20px 20px;
        box-shadow:  0 8px 8px rgba(8, 4, 3, 0.1);
        
        overflow: hidden;
    background-color: #ffff;
    
      }
      h2{
        justify-content:center;
        text-align:center;
      }
      .login-form input {
    width: 100%;
    padding:8px;
    border: 0.5px solid black;
      }



    </style>
</head>
<body>
<?php include("header.php");?>
    <div class="container my-5">
        <div class="row d-flex justify-content-center">
            <div class="col-lg-5 col-12">
                <div class="login-form border  p-4 ">
            <h2 style="color:maroon;">Register</h2>
            <form action="register.php" class="form" method="post" >
                <div class="form-group">
              <label for="username">Name</label>
                <input type="text" id="username" name="Name"placeholder="Enter your Full Name" class="form-control ">
                </div>
                <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="Email"placeholder="Enter email" class="form-control ">
                </div>
                <div class="form-group">
                <label for="password">Contact</label>
                <input type="number" id="" name="Contact" placeholder="Mobile number" class="form-control ">
                </div>
                <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="Password"placeholder="Enter the password" class="form-control ">
                </div><br>
                <button type="submit" name="sub" class="form-control" style="background-color:maroon;color:White; width:100%; padding:10px;">Register</button>
                  <p style="color:black;">Allready have an account ? <a href="login.php" style="color:red;">login</a></p> 
            </form>
            </div>
        </div>
    </div>
       
 </div>
    <?php include("footer.php");?>
</body>

</html>
\