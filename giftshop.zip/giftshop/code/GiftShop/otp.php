<?php
  include("connect.php");
  session_start();
  $Email=$_SESSION['Email'];
  if(isset($_POST['sub']))
  {
    $otp=$_POST['otp'];
    $sql="select otp from otp where Email='$Email' and otp='$otp'";
    $res=mysqli_query($con,$sql);
    if(mysqli_num_rows($res)>0)
    {
        header("location:change-password.php");

    }
    else{
        $msg="Invalid OTP";
    }
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include("cdn.php");?>
    <style>
         .table{
            border-radius:20px 20px;
        }
        .table input{
            width: 100%;
 margin-top:10px;
 border:1px solid black;
        }
    </style>
</head>
<body>
    <div class="container my-5">
        <div class="row d-flex justify-content-center">
            <div class="col-lg-5">
                <div class="table border p-5">
                <h3>OTP Confirmation</h3>
                <form method="post" class="form p-3">
                    <div class="form-group">
                        <label for="">OTP</label>
                        <input type="password" placeholder="Enter OTP" class="form-control" name="otp">     
                    </div>
                    <div class="form-group">
                        <input type="submit" value="Submit" name="sub" class="btn" style="width:100%; background-color:maroon; color:white;">
                        <p><?php if(isset($msg)) echo $msg; ?></p>
                    </div>
                </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>