<?php
$con=mysqli_connect("localhost","root","","rk_collection");
if(mysqli_connect_error())
{
    echo "connection failed";
}
else
{
    echo "";
}
?>